# AdCS Pro — 대대행 매체 CS 자동화

## 로컬 실행
```bash
npm install
npm start
```

## Vercel 무료 배포 (권장)
1. [vercel.com](https://vercel.com) 회원가입 (GitHub 로그인)
2. GitHub에 이 폴더 업로드
3. Vercel → "New Project" → 레포 선택 → Deploy
4. 완료 — URL 자동 생성

## Netlify 배포
1. `npm run build` 실행
2. [netlify.com](https://netlify.com) → "Deploy manually" → `build` 폴더 드래그앤드롭

## 앱처럼 사용 (PWA)
Chrome에서 배포 URL 접속 → 주소창 오른쪽 설치 아이콘 클릭 → 바탕화면 앱으로 설치
